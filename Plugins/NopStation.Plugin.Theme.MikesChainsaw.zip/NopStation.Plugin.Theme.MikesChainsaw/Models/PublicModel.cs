﻿namespace Nop.Plugin.NopStation.Theme.MikesChainsaw.Models;

public class PublicModel
{
    public string CustomCss { get; set; }

    public bool EnableImageLazyLoad { get; set; }
}
